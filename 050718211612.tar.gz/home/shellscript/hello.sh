#!/bin/bash
clear;
echo -n "Digite o seu nome: ";
read nome;
echo "Hello "$nome;
exit;
