#!/bin/bash
clear;
echo "__________TABUADA__________";
echo "";
echo -n "Digite o valor da tabuada: ";
read tabuada;
for i in $(seq 1 10)
do
echo "$tabuada x $i = $[tabuada*i]";
done 
exit;
